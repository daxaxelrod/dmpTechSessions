def run_calculator():
    print("Running the calculator")

def add(number_1, number_2):
    result = number_1 + number_2
    return result
    
def subtract(number_1, number_2):
    result = number_1 - number_2
    return result
