# def add(number_1, number_2):
#     result = number_1 + number_2
#     return result
#
# def subtract(number_1, number_2):
#     result = number_1 - number_2
#     return result

def run_calculator():
    print("Running the calculator")
    answer = raw_input("What function are we doing?")
    print("I see you want to do {} ".format(answer))

run_calculator()
